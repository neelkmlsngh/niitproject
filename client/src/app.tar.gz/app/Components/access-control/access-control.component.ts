import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-access-control',
  templateUrl: './access-control.component.html',
  styleUrls: ['./access-control.component.css']
})
export class AccessControlComponent implements OnInit {

 public data:any;

  constructor() { }

  ngOnInit() {

  }
  onRadio(data:any)
  {
    console.log("Hi data is here", data);
    this.data=data;
    console.log(this.data);
  }

}
