import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule, Http } from '@angular/http'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'

import { AppComponent } from './app.component';
/*import { Ir71Component } from './ir71/ir71.component';*/
import { LoginComponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { AccessControlComponent } from './access-control/access-control.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { EmployeeComponent } from './employee/employee.component';
import { SupervisorComponent } from './supervisor/supervisor.component';
import { HrComponent } from './hr/hr.component';
import { CsoComponent } from './cso/cso.component';
import { CisoComponent } from './ciso/ciso.component';
import { CategoryComponent } from './category/category.component';
import { AcessTypeComponent } from './accesstype/acesstype.component';
import { ControlAccessService } from '../Services/control-access.service';

@NgModule({
  declarations: [
    AppComponent,
    /*Ir71Component,*/
    LoginComponent,
    RegisterComponent,
    AccessControlComponent,
    NavbarComponent,
    FooterComponent,
    EmployeeComponent,
    SupervisorComponent,
    HrComponent,
    CsoComponent,
    CisoComponent,
    CategoryComponent,
    AcessTypeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot([
    {
      path:'',redirectTo:'/category',pathMatch:'full'
    },
      {
        path: 'login', 
        component: LoginComponent
      },
     {
        path:'form',
        component:EmployeeComponent
      },
      {
        path:'register',
        component:RegisterComponent
      },
      {
        path:'navbar',
        component:NavbarComponent
      },
       {
        path:'category',
        component:CategoryComponent
      },
      {
        path:'cso',
        component:CsoComponent
      },
      {
        path:'acesstype',
        component:AcessTypeComponent
      }

      ])
  ],
  providers: [ControlAccessService],
  bootstrap: [AppComponent]
})
export class AppModule { }
