import { Component, OnInit,Input,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

	category:string="";

	selectedcategory:string="";

  a:string="";



@Input('data') data:any;


  constructor() { }

OnRadioButtonSelection()
{
	//this.radioChanged.emit(this.category);
	console.log(this.category);
	this.selectedcategory=this.category;

}


onRadio(data)
{
  console.log('Data is here', data);
  this.a=data;
}




  ngOnInit() {
  	
  }

}
