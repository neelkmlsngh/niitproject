import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ciso',
  templateUrl: './ciso.component.html',
  styleUrls: ['./ciso.component.css']
})
export class CisoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
