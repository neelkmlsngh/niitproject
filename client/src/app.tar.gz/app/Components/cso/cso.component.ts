import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cso',
  templateUrl: './cso.component.html',
  styleUrls: ['./cso.component.css']
})
export class CsoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
