import { Component,OnInit } from '@angular/core';
import { ControlAccessService } from '../../Services/control-access.service'

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

	employeeDetail:any=[];
	employeeID:String;

  constructor(private controlAccess:ControlAccessService){
     
     
}



 save(){

 	const employee={
 		employeeID: this.employeeID
 	}
 	this.controlAccess.save(employee).subscribe(data=>{

 	})
 	console.log(employee)

// this.employeeDetail = {

//    "employeeID": detail.employeeID,
//    "employeeName": detail.employeeName,
//    "accessType": detail.accessType,
//    "designation":detail.designation,
//    "dateOfJoining":detail.dateOfJoining,
//    "dateOfExpiry":detail.dateOfExpiry,
//    "project":detail.project,
//    "department":detail.department,
//    "existingProject":detail.existingProject,
//    "newProject":detail.newProject
// }

//    this.controlAccess.save(this.employeeDetail).subscribe((data)=>{
 
//  })

   }

   ngOnInit()
   {
   	this.controlAccess.getEmployee().subscribe(data=>{
   		console.log(data);
   	})
   }

}