import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';


@Injectable()
export class ControlAccessService {

  constructor(private http: Http) { }


  save(employee) {
  	console.log(employee)
 return this.http
             .post('http://localhost:5000/insert',employee)
             .map(res=>res.json());

}

getEmployee()
{
	return this.http
	            .get('http://localhost:5000/show')
	            .map(res=>res.json());
}



}
