import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ir71',
  templateUrl: './ir71.component.html',
  styleUrls: ['./ir71.component.css']
})
export class Ir71Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
